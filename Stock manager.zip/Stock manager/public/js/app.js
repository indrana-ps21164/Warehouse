const API_BASE = "/api/auth";

function showAlert(type, message) {
  const alertBox = document.getElementById("alertBox");
  if (!alertBox) return;

  alertBox.innerHTML = `
    <div class="alert alert-${type} alert-dismissible fade show" role="alert">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  `;
}

async function apiFetch(url, options = {}) {
  const response = await fetch(url, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || "Request failed");
  }

  return data;
}

function redirectByRole(role) {
  if (["ADMIN", "STOCK_KEEPER", "PLANNER"].includes(role)) {
    window.location.href = "/dashboard.html";
    return;
  }

  window.location.href = "/login.html";
}

async function handleLoginPage() {
  const loginForm = document.getElementById("loginForm");
  if (!loginForm) return;

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    if (!email || !password) {
      showAlert("danger", "Email and password are required.");
      return;
    }

    try {
      const result = await apiFetch(`${API_BASE}/login`, {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });

      showAlert("success", result.message || "Login successful.");
      setTimeout(() => redirectByRole(result.user.role), 600);
    } catch (error) {
      showAlert("danger", error.message || "Login failed.");
    }
  });
}

async function handleRegisterPage() {
  const registerForm = document.getElementById("registerForm");
  if (!registerForm) return;

  try {
    const me = await apiFetch(`${API_BASE}/me`);
    if (me.user.role !== "ADMIN") {
      showAlert("danger", "Only ADMIN can access register page.");
      setTimeout(() => (window.location.href = "/dashboard.html"), 800);
      return;
    }
  } catch (error) {
    window.location.href = "/login.html";
    return;
  }

  registerForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    if (!name || !email || !password || !role) {
      showAlert("danger", "All fields are required.");
      return;
    }

    if (password.length < 6) {
      showAlert("danger", "Password must be at least 6 characters.");
      return;
    }

    try {
      const result = await apiFetch(`${API_BASE}/register`, {
        method: "POST",
        body: JSON.stringify({ name, email, password, role }),
      });

      showAlert("success", result.message || "User created successfully.");
      registerForm.reset();
    } catch (error) {
      showAlert("danger", error.message || "Could not create user.");
    }
  });
}

async function loadAdminUsers() {
  const tableBody = document.getElementById("usersTableBody");
  if (!tableBody) return;

  try {
    const result = await apiFetch(`${API_BASE}/users`);
    tableBody.innerHTML = "";

    result.users.forEach((user) => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${user.name}</td>
        <td>${user.email}</td>
        <td>${user.role}</td>
        <td>${new Date(user.createdAt).toLocaleString()}</td>
      `;
      tableBody.appendChild(row);
    });
  } catch (error) {
    showAlert("danger", error.message || "Failed to load users.");
  }
}

async function handleDashboardPage() {
  const userName = document.getElementById("userName");
  if (!userName) return;

  let user;
  try {
    const me = await apiFetch(`${API_BASE}/me`);
    user = me.user;
  } catch (error) {
    window.location.href = "/login.html";
    return;
  }

  userName.textContent = user.name;
  document.getElementById("roleBadge").textContent = user.role;

  const adminSection = document.getElementById("adminSection");
  const stockSection = document.getElementById("stockSection");
  const plannerSection = document.getElementById("plannerSection");

  if (user.role === "ADMIN") {
    adminSection.classList.remove("d-none");
    await loadAdminUsers();
  } else if (user.role === "STOCK_KEEPER") {
    stockSection.classList.remove("d-none");
  } else if (user.role === "PLANNER") {
    plannerSection.classList.remove("d-none");
  }

  const stockInBtn = document.getElementById("stockInBtn");
  if (stockInBtn) {
    stockInBtn.addEventListener("click", async () => {
      try {
        const result = await apiFetch("/api/stock/in", { method: "POST", body: JSON.stringify({}) });
        showAlert("success", result.message);
      } catch (error) {
        showAlert("danger", error.message);
      }
    });
  }

  const stockOutBtn = document.getElementById("stockOutBtn");
  if (stockOutBtn) {
    stockOutBtn.addEventListener("click", async () => {
      try {
        const result = await apiFetch("/api/stock/out", { method: "POST", body: JSON.stringify({}) });
        showAlert("success", result.message);
      } catch (error) {
        showAlert("danger", error.message);
      }
    });
  }

  const loadReportsBtn = document.getElementById("loadReportsBtn");
  const reportsList = document.getElementById("reportsList");
  if (loadReportsBtn && reportsList) {
    loadReportsBtn.addEventListener("click", async () => {
      try {
        const result = await apiFetch("/api/reports", { method: "GET" });
        reportsList.innerHTML = "";

        result.reports.forEach((report) => {
          const item = document.createElement("li");
          item.className = "list-group-item d-flex justify-content-between align-items-center";
          item.innerHTML = `<span>${report.title}</span><span class="badge text-bg-success">${report.status}</span>`;
          reportsList.appendChild(item);
        });
      } catch (error) {
        showAlert("danger", error.message);
      }
    });
  }
}

async function attachLogoutHandler() {
  const logoutBtn = document.getElementById("logoutBtn");
  if (!logoutBtn) return;

  logoutBtn.addEventListener("click", async () => {
    try {
      await apiFetch(`${API_BASE}/logout`, { method: "POST", body: JSON.stringify({}) });
    } catch (error) {
    } finally {
      window.location.href = "/login.html";
    }
  });
}

(async function init() {
  await attachLogoutHandler();
  await handleLoginPage();
  await handleRegisterPage();
  await handleDashboardPage();
})();
