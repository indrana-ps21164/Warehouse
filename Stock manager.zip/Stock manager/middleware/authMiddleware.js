const User = require("../models/User");

/**
 * Ensures the request has a valid session and attaches the current user.
 */
const requireAuth = async (req, res, next) => {
  try {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ message: "Unauthorized. Please login." });
    }

    const user = await User.findById(req.session.userId).select("-password");
    if (!user) {
      req.session.destroy(() => {});
      return res.status(401).json({ message: "Session invalid. Please login again." });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(500).json({ message: "Authentication middleware error." });
  }
};

/**
 * Factory middleware to enforce allowed roles for a protected endpoint.
 */
const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "Unauthorized. Please login." });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ message: "Forbidden. Insufficient role." });
    }

    next();
  };
};

// Shortcut middleware for common single-role access checks.
const adminOnly = requireRole("ADMIN");
const stockKeeperOnly = requireRole("STOCK_KEEPER");
const plannerOnly = requireRole("PLANNER");

module.exports = {
  requireAuth,
  requireRole,
  adminOnly,
  stockKeeperOnly,
  plannerOnly,
};
