const express = require("express");
const mongoose = require("mongoose");
const Item = require("../models/Item");
const Transaction = require("../models/Transaction");
const { requireAuth, stockKeeperOnly } = require("../middleware/authMiddleware");

const router = express.Router();

/**
 * Internal helper to create a stock transaction.
 * Used by stock IN and stock OUT endpoints.
 */
const createStockTransaction = async (req, res, type) => {
  try {
    const { itemId, quantity } = req.body;

    if (!itemId || !mongoose.Types.ObjectId.isValid(itemId)) {
      return res.status(400).json({ message: "Valid itemId is required." });
    }

    if (!quantity || Number(quantity) <= 0) {
      return res.status(400).json({ message: "Quantity must be greater than zero." });
    }

    const item = await Item.findById(itemId);
    if (!item) {
      return res.status(404).json({ message: "Item not found." });
    }

    const transaction = await Transaction.create({
      itemId,
      type,
      quantity: Number(quantity),
      createdBy: req.user._id,
    });

    return res.status(201).json({
      message: `Stock ${type} recorded successfully.`,
      transaction,
    });
  } catch (error) {
    return res.status(500).json({ message: "Failed to record stock transaction." });
  }
};

/**
 * STOCK_KEEPER route to record stock IN.
 */
router.post("/in", requireAuth, stockKeeperOnly, async (req, res) => {
  return createStockTransaction(req, res, "IN");
});

/**
 * STOCK_KEEPER route to record stock OUT.
 */
router.post("/out", requireAuth, stockKeeperOnly, async (req, res) => {
  return createStockTransaction(req, res, "OUT");
});

module.exports = router;
