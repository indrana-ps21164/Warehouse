const express = require("express");
const Item = require("../models/Item");
const Transaction = require("../models/Transaction");
const { requireAuth, plannerOnly } = require("../middleware/authMiddleware");

const router = express.Router();

/**
 * Returns current stock view for planners by combining items with transactions.
 * Access is intentionally restricted to PLANNER role.
 */
router.get("/stock", requireAuth, plannerOnly, async (req, res) => {
  try {
    const [items, stockAggregation] = await Promise.all([
      Item.find().lean(),
      Transaction.aggregate([
        {
          $group: {
            _id: "$itemId",
            stockIn: {
              $sum: {
                $cond: [{ $eq: ["$type", "IN"] }, "$quantity", 0],
              },
            },
            stockOut: {
              $sum: {
                $cond: [{ $eq: ["$type", "OUT"] }, "$quantity", 0],
              },
            },
          },
        },
      ]),
    ]);

    const stockMap = new Map();
    stockAggregation.forEach((entry) => {
      stockMap.set(String(entry._id), {
        stockIn: entry.stockIn || 0,
        stockOut: entry.stockOut || 0,
      });
    });

    const stockView = items.map((item) => {
      const totals = stockMap.get(String(item._id)) || { stockIn: 0, stockOut: 0 };
      const currentStock = totals.stockIn - totals.stockOut;

      return {
        id: item._id,
        itemCode: item.itemCode,
        name: item.name,
        category: item.category,
        unit: item.unit,
        minLevel: item.minLevel,
        currentStock,
        lowStock: currentStock <= item.minLevel,
      };
    });

    return res.status(200).json({ stock: stockView });
  } catch (error) {
    return res.status(500).json({ message: "Failed to load stock view." });
  }
});

module.exports = router;
