const mongoose = require("mongoose");

// Atlas connection string requested by the user.
const ATLAS_URI =
  "mongodb+srv://indranaps21164_db_user:BNwV1T9hMjg33dQ5@cluster0.fconl5x.mongodb.net/?appName=Cluster0";

/**
 * Connects the application to MongoDB Atlas.
 * Uses an environment override when MONGO_URI is provided.
 */
const connectDB = async () => {
  const mongoUri = process.env.MONGO_URI || ATLAS_URI;

  try {
    await mongoose.connect(mongoUri);
    console.log("MongoDB connected successfully.");
  } catch (error) {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  }
};

module.exports = connectDB;
